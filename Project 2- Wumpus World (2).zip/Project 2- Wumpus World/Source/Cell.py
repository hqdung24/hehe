from enum import Enum

class Object(Enum):
    GOLD   = 'G'
    PIT    = 'P'
    WUMPUS = 'W'
    BREEZE = 'B'
    STENCH = 'S'
    AGENT  = 'A'
    POISONOUS_GAS = 'P_G'
    HEALING_POTIONS = 'H_P'
    WHIFF = 'W_H'
    GLOW = 'G_L'
    EMPTY  = '-'

class Cell:
    def __init__(self, matrix_pos, map_size, object_str):
        self.matrix_pos = matrix_pos                                            
        self.map_pos = matrix_pos[1] + 1, map_size - matrix_pos[0]              
        self.index_pos = map_size * (self.map_pos[1] - 1) + self.map_pos[0]    
        self.map_size = map_size
        self.explored = False
        self.object = [False] * 9 
        self.str_to_object(object_str)

        self.parent = None
        self.child_list = []

    def check_index(self, map_size, index):
        return 0 <= index < map_size

    def breeze_preprocess(self, raw_map, map_size, i, j):
        if self.check_index(map_size, j + 1):
            if raw_map[i][j + 1] == '-':
                raw_map[i][j + 1] = ''
            raw_map[i][j + 1] += 'B'
        
        if self.check_index(map_size, i + 1):
            if raw_map[i + 1][j] == '-':
                raw_map[i + 1][j] = ''
            raw_map[i + 1][j] += 'B'
                
        if self.check_index(map_size, i - 1):
            if raw_map[i - 1][j] == '-':
                raw_map[i - 1][j] = ''
            raw_map[i - 1][j] += 'B'
                
        if self.check_index(map_size, j - 1):
            if raw_map[i][j - 1] == '-':
                raw_map[i][j - 1] = ''
            raw_map[i][j - 1] += 'B'

    def stench_preprocess(self, raw_map, map_size, i, j):
        if self.check_index(map_size, j + 1):
            if raw_map[i][j + 1] == '-':
                raw_map[i][j + 1] = ''
            raw_map[i][j + 1] += 'S'
        
        if self.check_index(map_size, i + 1):
            if raw_map[i + 1][j] == '-':
                raw_map[i + 1][j] = ''
            raw_map[i + 1][j] += 'S'
                
        if self.check_index(map_size, i - 1):
            if raw_map[i - 1][j] == '-':
                raw_map[i - 1][j] = ''
            raw_map[i - 1][j] += 'S'
                
        if self.check_index(map_size, j - 1):
            if raw_map[i][j - 1] == '-':
                raw_map[i][j - 1] = ''
            raw_map[i][j - 1] += 'S'

    def whiff_preprocess(self, raw_map, map_size, i, j):
        if self.check_index(map_size, j + 1):
            if raw_map[i][j + 1] == '-':
                raw_map[i][j + 1] = ''
            raw_map[i][j + 1] += 'W_H'
        
        if self.check_index(map_size, i + 1):
            if raw_map[i + 1][j] == '-':
                raw_map[i + 1][j] = ''
            raw_map[i + 1][j] += 'W_H'
                
        if self.check_index(map_size, i - 1):
            if raw_map[i - 1][j] == '-':
                raw_map[i - 1][j] = ''
            raw_map[i - 1][j] += 'W_H'
                
        if self.check_index(map_size, j - 1):
            if raw_map[i][j - 1] == '-':
                raw_map[i][j - 1] = ''
            raw_map[i][j - 1] += 'W_H'

    def glow_preprocess(self, raw_map, map_size, i, j):
        if self.check_index(map_size, j + 1):
            if raw_map[i][j + 1] == '-':
                raw_map[i][j + 1] = ''
            raw_map[i][j + 1] += 'G_L'
        
        if self.check_index(map_size, i + 1):
            if raw_map[i + 1][j] == '-':
                raw_map[i + 1][j] = ''
            raw_map[i + 1][j] += 'G_L'
                
        if self.check_index(map_size, i - 1):
            if raw_map[i - 1][j] == '-':
                raw_map[i - 1][j] = ''
            raw_map[i - 1][j] += 'G_L'
                
        if self.check_index(map_size, j - 1):
            if raw_map[i][j - 1] == '-':
                raw_map[i][j - 1] = ''
            raw_map[i][j - 1] += 'G_L'
    
    def generate_sign(self, raw_map):
        for i in range(10):
            for j in range(10):
                if Object.HEALING_POTIONS.value in raw_map[i][j]:
                    self.glow_preprocess(raw_map, self.map_size, i, j)
                if Object.POISONOUS_GAS.value in raw_map[i][j]:
                    self.whiff_preprocess(raw_map, self.map_size, i, j)
                if Object.WUMPUS.value in raw_map[i][j]:
                    if ('W_H' in raw_map[i][j]):
                        count = raw_map[i][j].count('W') 
                        if (count > 1):
                            self.stench_preprocess(raw_map, self.map_size, i, j)
                    else:
                        self.stench_preprocess(raw_map, self.map_size, i, j)
                if Object.PIT.value in raw_map[i][j] :
                    count = raw_map[i][j].count('P')
                    print('HERE') 
                    if 'H_P' in raw_map[i][j]  and 'P_G' in raw_map[i][j]:
                        if(count > 2):
                            self.breeze_preprocess(raw_map, self.map_size, i, j)
                    elif 'H_P' in raw_map[i][j] or 'P_G' in raw_map[i][j]:
                        if(count > 1):
                            self.breeze_preprocess(raw_map, self.map_size, i, j)
                    else:
                        self.breeze_preprocess(raw_map, self.map_size, i, j)
                if '-' in raw_map[i][j] and raw_map[i][j] != '-':
                    raw_map[i][j] = raw_map[i][j].replace('-', '')

    def str_to_object(self, object_str):
        if Object.POISONOUS_GAS.value in object_str:
            self.object[5] = True
        if Object.HEALING_POTIONS.value in object_str:
            self.object[6] = True
        if Object.WHIFF.value in object_str:
            self.object[7] = True
        if Object.GLOW.value in object_str:
            self.object[8] = True

        if Object.GOLD.value in object_str:
            if(Object.GLOW.value in object_str and Object.POISONOUS_GAS.value in object_str):
                count = object_str.count('G')
                if(count > 2):
                    self.object[0] = True
            elif(Object.GLOW.value in object_str):
                count = object_str.count('G')
                if(count > 1):
                    self.object[0] = True
            elif(Object.POISONOUS_GAS.value in object_str):
                count = object_str.count('G')
                if(count > 1):
                    self.object[0] = True
            else:
                self.object[0] = True    
        if Object.PIT.value in object_str:
            if(Object.HEALING_POTIONS.value in object_str and Object.POISONOUS_GAS.value in object_str):
                count = object_str.count('P')
                if(count > 2):
                    self.object[1] = True
            elif(Object.HEALING_POTIONS.value in object_str):
                count = object_str.count('P')
                if(count > 1):
                    self.object[1] = True
            elif(Object.POISONOUS_GAS.value in object_str):
                count = object_str.count('P')
                if(count > 1):
                    self.object[1] = True
            else:
                self.object[1] = True      
        if Object.WUMPUS.value in object_str:
            if(Object.WHIFF.value in object_str):
                count = object_str.count('W') 
                if(count > 1):
                    self.object[2] = True
            else:
                self.object[2] = True
        if Object.BREEZE.value in object_str:
            self.object[3] = True
        if Object.STENCH.value in object_str:
            self.object[4] = True

    def exist_gold(self):
        return self.object[0]

    def exist_pit(self):
        return self.object[1]

    def exist_wumpus(self):
        return self.object[2]

    def exist_breeze(self):
        return self.object[3]

    def exist_stench(self):
        return self.object[4]
    
    def exist_poison(self):
        return self.object[5]
    
    def exist_health(self):
        return self.object[6]

    def exist_whiff(self):
        return self.object[7]
    
    def exist_glow(self):
        return self.object[8]

    def is_safe(self):
        return not self.exist_breeze() and not self.exist_stench() and not self.exist_whiff()


    def update_parent(self, parent_cell):
        self.parent = parent_cell

    def grab_gold(self):
        self.object[0] = False

    def grab_health(self):
        self.object[6] = False

    def grab_poison(self):
        self.object[5] = True

    def kill_wumpus(self, cell_matrix, kb):
        # delete wumpus in this cell
        self.object[2] = False

        # delete stench around this cell
        adj_cell = self.get_adj_cell_list(cell_matrix)
        stench_cell: Cell
        for stench_cell in adj_cell:
            flag = True
            adj_this_stench = stench_cell.get_adj_cell_list(cell_matrix)
            cell_wumpus: Cell
            for cell_wumpus in adj_this_stench:
                if cell_wumpus.exist_wumpus():
                    # have wumpus
                    flag = False
                    break

            # if no another wumpus around this cell => delete stench_cell
            if flag:
                stench_cell.object[4] = False

                # TODO: Will check again here
                # delete clause have stench
                kb.del_clause([stench_cell.get_literal(Object.STENCH, '+')])
                # add clause dont have stench
                kb.add_clause([stench_cell.get_literal(Object.STENCH, '-')])
                # TODO: End

                adj_cell_list = stench_cell.get_adj_cell_list(cell_matrix)
                # BASE KNOWLEDGE: S <=> Wa v Wb v Wc v Wd
                # (S => Wa v Wb v Wc v Wd) <=> (-S v Wa v Wb v Wc v Wd) (De Morgan)
                cell_adj: Cell
                clause = [cell_adj.get_literal(Object.WUMPUS, '+') for cell_adj in adj_cell_list]
                clause.append(stench_cell.get_literal(Object.STENCH, '-'))
                kb.del_clause(clause)

                # (Wa v Wb v Wc v Wd => S) <=> ((-Wa ^ -Wb ^ -Wc ^ -Wd) v S)
                for cell_adj in adj_cell_list:
                    kb.del_clause([stench_cell.get_literal(Object.STENCH, '+'), cell_adj.get_literal(Object.WUMPUS,
                                                                                                       '-')])
    def get_adj_cell_list(self, cell_matrix):
        adj_cell_list = []
        adj_cell_matrix_pos_list = [(self.matrix_pos[0], self.matrix_pos[1] + 1),   # Right
                                    (self.matrix_pos[0], self.matrix_pos[1] - 1),   # Left
                                    (self.matrix_pos[0] - 1, self.matrix_pos[1]),   # Up
                                    (self.matrix_pos[0] + 1, self.matrix_pos[1])]   # Down

        for adj_cell_matrix_pos in adj_cell_matrix_pos_list:
            if 0 <= adj_cell_matrix_pos[0] < self.map_size and 0 <= adj_cell_matrix_pos[1] < self.map_size:
                adj_cell_list.append(cell_matrix[adj_cell_matrix_pos[0]][adj_cell_matrix_pos[1]])

        return adj_cell_list


    def is_explored(self):
        return self.explored

    def explore(self):
        self.explored = True


    def update_child_list(self, valid_adj_cell_list):
        for adj_cell in valid_adj_cell_list:
            if adj_cell.parent is None:
                self.child_list.append(adj_cell)
                adj_cell.update_parent(self)


    def get_literal(self, obj: Object, sign = '+'):    # sign='-': not 
        if obj == Object.PIT:
            i = 1
        elif obj == Object.WUMPUS:
            i = 2
        elif obj == Object.BREEZE:
            i = 3
        elif obj == Object.STENCH:
            i = 4
        elif obj == Object.POISONOUS_GAS:
            i = 5
        elif obj == Object.WHIFF:
            i = 6
        elif obj == Object.HEALING_POTIONS:
            i = 7
        elif obj == Object.GLOW:
            i = 8
        else:
            raise TypeError('Error: ' + self.get_literal.__name__)

        factor = 10 ** len(str(self.map_size * self.map_size))
        literal = i * factor + self.index_pos
        if sign == '-':
            literal *= -1

        return literal

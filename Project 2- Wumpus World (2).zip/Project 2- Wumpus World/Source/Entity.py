import pygame
from Setting import *

class Agent(pygame.sprite.Sprite):
    def __init__(self, i, j):
        pygame.sprite.Sprite.__init__(self)
        self.score = 0
        self.hp = 100
        self.hp_bag = 0
        self.image = pygame.image.load(IMG_AGENT_RIGHT).convert_alpha() #initial state of agent
        self.agent_state = []
        self.spacing = 69
        self.row= i - 1
        self.col= j - 1
        self.y = 43 + self.row * self.spacing
        self.x = 43 + self.col * self.spacing
        self.rect = self.image.get_rect()
        self.rect.center = (self.x, self.y)
        
    def load_image(self):
        self.agent_state.append(self.image)
        image_list = [IMG_AGENT_LEFT, IMG_AGENT_UP, IMG_AGENT_DOWN]
        for img in image_list:
            self.agent_state.append(pygame.image.load(img).convert_alpha())

    def get_score(self):
        return self.score
    
    def get_hp(self):
        if (self.hp < 100):
            self.hp += self.hp_bag * 25 
            if (self.hp_bag >= 1):
                self.hp_bag -= 1
        return self.hp
    def move_forward(self, direct):
        if direct == 0:
            self.move_up()
        elif direct == 1:
            self.move_down()
        elif direct == 2:
            self.move_left()
        elif direct == 3:
            self.move_right()

    def move_up(self):
        self.y -= self.spacing
        self.score -= 10
        if self.row> 0:
            self.row-= 1

    def move_down(self):
        self.y += self.spacing
        self.score -= 10
        if self.row< 9:
            self.row+= 1

    def move_left(self):
        self.x -= self.spacing
        self.score -= 10
        if self.col> 0:
            self.col-= 1

    def move_right(self):
        self.x += self.spacing
        self.score -= 10
        if self.col< 9:
            self.col+= 1

    def turn_up(self):
        self.image = self.agent_state[3]
        return 0

    def turn_down(self):
        self.image = self.agent_state[2]
        return 1

    def turn_left(self):
        self.image = self.agent_state[1]
        return 2

    def turn_right(self):
        self.image = self.agent_state[0]
        return 3

    def update(self):
        if self.x > 670:
            self.x -= self.spacing
            self.score += 10

        elif self.x < 40:
            self.x += self.spacing
            self.score += 10

        elif self.y < 40:
            self.y += self.spacing
            self.score += 10

        elif self.y > 670:
            self.y -= self.spacing
            self.score += 10

        self.rect.center = (self.x, self.y)

    def get_pos(self):
        return self.row, self.col

    def shoot(self):
        self.score -= 100

    def eliminated(self):
        self.score -= 10000

    def grab_gold(self):
        self.score += 5000

    def grab_health(self):
        self.hp_bag += 1

    def get_poisoned(self):
        self.hp -= 25

    def climb(self):
        self.score += 10

class Pit:
    def __init__(self, x, y):
        self.is_discovered = False
        self.noti = [[False] * GRID_SIZE for _ in range(GRID_SIZE)]
        self.pit_pos = [[False] * GRID_SIZE for _ in range(GRID_SIZE)]
        for i in range(len(x)):
            self.pit_pos[x[i]][y[i]] = True

    def pit_discovered(self):
        self.is_discovered = True

    def pit_notification(self):
        for i in range(GRID_SIZE):
            for j in range(GRID_SIZE):
                if self.pit_pos[i][j]:
                    self._update_notifications(i, j)

    def _update_notifications(self, i, j):
        if i > 0:
            self.noti[i - 1][j] = True
        if i < GRID_SIZE - 1:
            self.noti[i + 1][j] = True
        if j > 0:
            self.noti[i][j - 1] = True
        if j < GRID_SIZE - 1:
            self.noti[i][j + 1] = True

    def update(self, screen, font, is_discovered):
        for i in range(GRID_SIZE):
            for j in range(GRID_SIZE):
                if self.noti[i][j] and is_discovered[i][j]:
                    self._display_text(screen, font, 'Breeze', (j, i), pygame.Color('green'))

    def _display_text(self, screen, font, text, position, color):
        text_surface = font.render(text, True, color)
        text_rect = text_surface.get_rect()
        text_rect.center = (OFFSET + position[0] * CELL_SIZE + 32, OFFSET + position[1] * CELL_SIZE + 30)
        screen.blit(text_surface, text_rect)
        pygame.display.update()

class Health:
    def __init__(self, x, y):
        self.is_discovered = False
        self.noti = [[False] * GRID_SIZE for _ in range(GRID_SIZE)]
        self.hp_pos = [[False] * GRID_SIZE for _ in range(GRID_SIZE)]
        for i in range(len(x)):
            self.hp_pos[x[i]][y[i]] = True

    def hp_discovered(self):
        self.is_discovered = True

    def hp_notification(self):
        for i in range(GRID_SIZE):
            for j in range(GRID_SIZE):
                if self.hp_pos[i][j]:
                    self._update_notifications(i, j)

    def _update_notifications(self, i, j):
        if i > 0:
            self.noti[i - 1][j] = True
        if i < GRID_SIZE - 1:
            self.noti[i + 1][j] = True
        if j > 0:
            self.noti[i][j - 1] = True
        if j < GRID_SIZE - 1:
            self.noti[i][j + 1] = True

    def update(self, screen, font, is_discovered):
        for i in range(GRID_SIZE):
            for j in range(GRID_SIZE):
                if self.noti[i][j] and is_discovered[i][j]:
                    self._display_text(screen, font, 'Glow', (j, i), pygame.Color('pink'))
    
    def grab_health(self, screen, font):
        text = font.render('Grab A Health Point!!!', True, pygame.Color('green'))
        textRect = text.get_rect()
        textRect.center = (835, 250)
        screen.blit(text, textRect)

    def _display_text(self, screen, font, text, position, color):
        text_surface = font.render(text, True, color)
        text_rect = text_surface.get_rect()
        text_rect.center = (OFFSET + position[0] * CELL_SIZE + 32, OFFSET + position[1] * CELL_SIZE + 30)
        screen.blit(text_surface, text_rect)
        pygame.display.update()

        
    def hp_grabbed(self, i, j):
        self.hp_pos[i][j] = False
        if i > 0:
            self.noti[i-1][j] = False
        if i < GRID_SIZE - 1:
            self.noti[i+1][j] = False
        if j > 0:
            self.noti[i][j - 1] = False
        if j < GRID_SIZE - 1:
            self.noti[i][j + 1] = False

class Poison:
    def __init__(self, x, y):
        self.is_discovered = False
        self.noti = [[False] * GRID_SIZE for _ in range(GRID_SIZE)]
        self.pg_pos = [[False] * GRID_SIZE for _ in range(GRID_SIZE)]
        for i in range(len(x)):
            self.pg_pos[x[i]][y[i]] = True

    def pg_discovered(self):
        self.is_discovered = True

    def pg_notification(self):
        for i in range(GRID_SIZE):
            for j in range(GRID_SIZE):
                if self.pg_pos[i][j]:
                    self._update_notifications(i, j)

    def get_poisoned(self, screen, font):
        text = font.render('Got Poisoned!!!', True, pygame.Color('purple'))
        textRect = text.get_rect()
        textRect.center = (835, 250)
        screen.blit(text, textRect)

    def _update_notifications(self, i, j):
        if i > 0:
            self.noti[i - 1][j] = True
        if i < GRID_SIZE - 1:
            self.noti[i + 1][j] = True
        if j > 0:
            self.noti[i][j - 1] = True
        if j < GRID_SIZE - 1:
            self.noti[i][j + 1] = True

    def update(self, screen, font, is_discovered):
        for i in range(GRID_SIZE):
            for j in range(GRID_SIZE):
                if self.noti[i][j] and is_discovered[i][j]:
                    self._display_text(screen, font, 'Whiff', (j, i), pygame.Color('purple'))

    def _display_text(self, screen, font, text, position, color):
        text_surface = font.render(text, True, color)
        text_rect = text_surface.get_rect()
        text_rect.center = (OFFSET + position[0] * CELL_SIZE + 32, OFFSET + position[1] * CELL_SIZE + 30)
        screen.blit(text_surface, text_rect)
        pygame.display.update()

class Wumpus:
    def __init__(self, x, y):
        self.is_discovered = None
        self.noti = [[False for _ in range(GRID_SIZE)] for _ in range(GRID_SIZE)]
        self.wumpus_pos = [[False for _ in range(GRID_SIZE)] for _ in range(GRID_SIZE)]
        for i in range(len(x)):
            self.wumpus_pos[x[i]][y[i]] = True

    def wumpus_scream(self, screen, font):
        # Draw the text for killing the Wumpus
        text = font.render('Killed a Wumpus!!!', True, pygame.Color('red'))
        textRect = text.get_rect()
        textRect.center = (835, 250)
        screen.blit(text, textRect)

    def wumpus_notification(self):
        for i in range(GRID_SIZE):
            for j in range(GRID_SIZE):
                if self.wumpus_pos[i][j]:
                    if i > 0:
                        self.noti[i - 1][j] = True
                    if i < GRID_SIZE - 1:
                        self.noti[i + 1][j] = True
                    if j > 0:
                        self.noti[i][j - 1] = True
                    if j < GRID_SIZE - 1:
                        self.noti[i][j + 1] = True

    def wumpus_killed(self, i, j):
        self.wumpus_pos[i][j] = False
        if i > 0:
            self.noti[i-1][j] = False
        if i < GRID_SIZE - 1:
            self.noti[i+1][j] = False
        if j > 0:
            self.noti[i][j - 1] = False
        if j < GRID_SIZE - 1:
            self.noti[i][j + 1] = False

    def update(self, screen, font, is_discovered):
        for i in range(GRID_SIZE):
            for j in range(GRID_SIZE):
                if self.noti[i][j] and is_discovered[i][j]:
                    text = font.render('Stench', True, pygame.Color('red'))
                    textRect = text.get_rect()
                    textRect.center = (45 + j * 70, 30 + i * 70)
                    screen.blit(text, textRect)


    def stench_i_j(self, i, j):
        return self.noti[i][j]

    def _display_text(self, screen, font, text, position, color):
        text_surface = font.render(text, True, color)
        text_rect = text_surface.get_rect()
        text_rect.center = (OFFSET + position[0] * CELL_SIZE + 35, OFFSET + position[1] * CELL_SIZE + 25)
        screen.blit(text_surface, text_rect)
        pygame.display.update()

class Gold:
    def __init__(self):
        self.image = pygame.image.load(IMG_GOLD).convert()
        self.image = pygame.transform.scale(self.image, (150, 300))

    def grab_gold(self, screen, font):
        self._display_text(screen, font, 'Found a gold chest!!!', (835, 250), pygame.Color('yellow'))
        self._display_text(screen, font, 'Score + 5000', (835, 350), pygame.Color('black'))

    def _display_text(self, screen, font, text, position, color):
        text_surface = font.render(text, True, color)
        text_rect = text_surface.get_rect()
        text_rect.center = position
        screen.blit(text_surface, text_rect)
        pygame.display.update()

class Arrow:
    def __init__(self):
        self.agent_state = []
        directions = [IMG_ARROW_RIGHT, IMG_ARROW_LEFT, IMG_ARROW_UP, IMG_ARROW_DOWN]
        for img_path in directions:
            img = pygame.image.load(img_path).convert_alpha()
            self.agent_state.append(img)

    def shoot(self, direction, screen, y, x):
        if direction == 0:
            self.shoot_up(screen, x, y)
        elif direction == 1:
            self.shoot_down(screen, x, y)
        elif direction == 2:
            self.shoot_left(screen, x, y)
        elif direction == 3:
            self.shoot_right(screen, x, y)

    def shoot_right(self, screen, x, y):
        self._shoot(screen, self.agent_state[0], x + 1, y)

    def shoot_left(self, screen, x, y):
        self._shoot(screen, self.agent_state[1], x - 1, y)

    def shoot_up(self, screen, x, y):
        self._shoot(screen, self.agent_state[2], x, y - 1)

    def shoot_down(self, screen, x, y):
        self._shoot(screen, self.agent_state[3], x, y + 1)

    def _shoot(self, screen, image, x, y):
        x_pos = OFFSET + x * CELL_SIZE
        y_pos = OFFSET + y * CELL_SIZE
        screen.blit(image, (x_pos, y_pos))
        pygame.display.update()

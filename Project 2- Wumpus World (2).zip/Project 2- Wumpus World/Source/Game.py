import sys
from Map import *
from Entity import *
from Solution import Solution
from Action import*

class Game:
    def __init__(self):
        pygame.init()
        pygame.font.init()
        self.background_image = pygame.image.load(BG_IMAGE) 
        self.screen = pygame.display.set_mode((SCREEN_WIDTH, SCREEN_HEIGHT))
        self.caption = pygame.display.set_caption(CAPTION)
        self.clock = pygame.time.Clock()
        self.font = pygame.font.Font(FONT, 30)
        self.noti = pygame.font.Font(FONT, 15)
        self.victory = pygame.font.Font(FONT, 50)
        self.winning_background = pygame.image.load(IMG_WIN).convert()
        self.winning_background = pygame.transform.scale(self.winning_background,(SCREEN_WIDTH, SCREEN_HEIGHT))
        self.losing_background = pygame.image.load(IMG_LOSE).convert()
        self.losing_background = pygame.transform.scale(self.losing_background,(SCREEN_WIDTH, SCREEN_HEIGHT))
        self.all_sprites = pygame.sprite.Group()
        self.game_state = MAP
        self.map_i = 1
        self.mouse = None
        self.direct = 3

    def update_screen(self):
        self.draw_noti()
        self.all_sprites.draw(self.screen)
        temp = self.map.discovered()
        self.all_sprites.update()
        self.wumpus.update(self.screen, self.noti, temp)
        self.pit.update(self.screen, self.noti, temp)
        self.poison.update(self.screen, self.noti, temp)
        self.health.update(self.screen, self.noti, temp)
    
    def draw_noti(self):
        self.screen.fill(LIGHT_GREY)
        self.map.draw(self.screen)
        score = self.agent.get_score()
        hp = self.agent.get_hp()
        self.draw_score(score)
        self.draw_hp(hp)

    def draw_score(self, score):
        text = self.font.render('SCORE: ' + str(score), True, BLACK)
        textRect = text.get_rect()
        textRect.center = (820, 25)

        padding = 10 
        rect_width = textRect.width + padding * 2
        rect_height = textRect.height + padding * 2
        rect_x = textRect.centerx - rect_width // 2
        rect_y = textRect.centery - rect_height // 2
        rect = pygame.Rect(rect_x, rect_y, rect_width, rect_height)

        pygame.draw.rect(self.screen, WHITE, rect)  
        pygame.draw.rect(self.screen, BLACK, rect, 2)  
        self.screen.blit(text, textRect)

    def draw_hp(self, hp):
        text = self.font.render('HP: ' + str(hp), True, GREEN)
        textRect = text.get_rect()
        textRect.center = (830, 100)
        padding = 10 
        rect_width = textRect.width + padding * 2
        rect_height = textRect.height + padding * 2
        rect_x = textRect.centerx - rect_width // 2
        rect_y = textRect.centery - rect_height // 2
        rect = pygame.Rect(rect_x, rect_y, rect_width, rect_height)
        pygame.draw.rect(self.screen, PINK, rect)  
        pygame.draw.rect(self.screen, BLACK, rect, 2)  
        self.screen.blit(text, textRect)
        text = self.font.render('HP Bag: ' + str(self.agent.hp_bag), True, GREEN)
        textRect = text.get_rect()
        textRect.center = (830, 170)
        padding = 10 
        rect_width = textRect.width + padding * 2
        rect_height = textRect.height + padding * 2
        rect_x = textRect.centerx - rect_width // 2
        rect_y = textRect.centery - rect_height // 2
        rect = pygame.Rect(rect_x, rect_y, rect_width, rect_height)
        pygame.draw.rect(self.screen, PINK, rect)  
        pygame.draw.rect(self.screen, BLACK, rect, 2)  
        self.screen.blit(text, textRect)

    def draw_winning_noti(self):
        text = self.font.render('Climb out!!!', True, PINK)
        textRect = text.get_rect()
        textRect.center = (830, 250)
        self.screen.blit(text, textRect)
        text = self.font.render('Score + 10', True, BLACK)
        textRect.center = (850, 300)
        self.screen.blit(text, textRect)

    def draw_button(self, surf, rect, button_color, text_color, text):
        pygame.draw.rect(surf, button_color, rect)
        text_surf = self.font.render(text, True, text_color)
        text_rect = text_surf.get_rect()
        text_rect.center = rect.center
        self.screen.blit(text_surf, text_rect)

    def home_menu(self):
        self.background_image = pygame.transform.scale(self.background_image, (SCREEN_WIDTH, SCREEN_HEIGHT))
        self.screen.blit(self.background_image, (0, 0))
        caption_font = pygame.font.Font(FONT_2, 100)
        caption_surface = caption_font.render("WUMPUS WORLD", True, RED)  # Render the text
        caption_rect = caption_surface.get_rect(center=(self.screen.get_width() / 2, 80))  # Position above the buttons
        self.screen.blit(caption_surface, caption_rect)
        button_positions = [
            (MAP_1_BUTTON, "MAP 1", 1),
            (MAP_2_BUTTON, "MAP 2", 2),
            (MAP_3_BUTTON, "MAP 3", 3),
            (MAP_4_BUTTON, "MAP 4", 4),
            (MAP_5_BUTTON, "MAP 5", 5),
            (EXIT_BUTTON, "EXIT", "EXIT")
        ]

        for event in pygame.event.get():
            if event.type == pygame.QUIT:
                pygame.quit()
                sys.exit()
            elif event.type == pygame.MOUSEBUTTONDOWN:
                for rect, _, map_value in button_positions:
                    if rect.collidepoint(self.mouse):
                        if map_value == "EXIT":
                            pygame.quit()
                            sys.exit()
                        self.game_state = RUNNING
                        self.map_i = map_value

        self.mouse = pygame.mouse.get_pos()
        for rect, text, map_value in button_positions:
            color = RED if rect.collidepoint(self.mouse) else BLACK
            bg_color = DARK_GREY if color == RED else LIGHT_GREY
            self.draw_button(self.screen, rect, bg_color, color, text)

        pygame.display.update()

    def result_noti(self):
        self.screen.fill(WHITE)
        if self.game_state == WIN or self.game_state == TRYBEST:
            self.screen.blit(self.winning_background, (0, 0))
            text = self.victory.render('', True, BLACK)
        elif self.game_state == GAMEOVER:
            self.screen.blit(self.losing_background, (0, 0))
            text = self.victory.render('', True, BLACK)
        textRect = text.get_rect()
        textRect.center = (500, 500)
        self.screen.blit(text, textRect)
        score = self.agent.get_score()
        
        text = self.victory.render('Your score: ' + str(score), True, YELLOW)
        textRect.center = (400, 500)
        self.screen.blit(text, textRect)

     
    def quit_game(self):
        for event in pygame.event.get():
            if event.type == pygame.QUIT:
                pygame.quit()
                sys.exit()
        pygame.display.update()
        pygame.time.delay(2000)
        self.game_state = MAP

    def initialize_game_elements(self):
        self.action_list, cave_cell, cell_matrix = Solution(MAP_LIST[self.map_i - 1], OUTPUT_LIST[self.map_i - 1]).solve_wumpus()
        map_pos = cave_cell.map_pos
        self.map = Map((len(cell_matrix) - map_pos[1] + 1, map_pos[0]))
        self.arrow = Arrow()
        self.gold = Gold()
        self.agent = Agent(len(cell_matrix) - map_pos[1] + 1, map_pos[0])
        self.agent.load_image()
        self.all_sprites = pygame.sprite.Group()
        self.all_sprites.add(self.agent)

        self.initialize_pits(cell_matrix)
        self.initialize_wumpus(cell_matrix)
        self.draw_noti()
        self.initialize_poison(cell_matrix)
        self.initialize_health(cell_matrix)

    def initialize_pits(self, cell_matrix):
        x, y = [], []
        for ir in range(len(cell_matrix)):
            for ic in range(len(cell_matrix)):
                if cell_matrix[ir][ic].exist_pit():
                    x.append(ir)
                    y.append(ic)
        self.pit = Pit(x, y)
        self.pit.pit_notification()

    def initialize_wumpus(self, cell_matrix):
        x, y = [], []
        for ir in range(len(cell_matrix)):
            for ic in range(len(cell_matrix)):
                if cell_matrix[ir][ic].exist_wumpus():
                    x.append(ir)
                    y.append(ic)
        self.wumpus = Wumpus(x, y)
        self.wumpus.wumpus_notification()

    def initialize_poison(self, cell_matrix):
        x, y = [], []
        for ir in range(len(cell_matrix)):
            for ic in range(len(cell_matrix)):
                if cell_matrix[ir][ic].exist_poison():
                    x.append(ir)
                    y.append(ic)
        self.poison = Poison(x, y)
        self.poison.pg_notification()

    def initialize_health(self, cell_matrix):
        x, y = [], []
        for ir in range(len(cell_matrix)):
            for ic in range(len(cell_matrix)):
                if cell_matrix[ir][ic].exist_health():
                    x.append(ir)
                    y.append(ic)
        self.health = Health(x, y)
        self.health.hp_notification()

    def check_quit_event(self):
        for event in pygame.event.get():
            if event.type == pygame.QUIT:
                pygame.quit()
                sys.exit()

    def display_action(self, action):
        if action == Action.TURN_LEFT:
            self.direct = self.agent.turn_left()
            self.update_screen()
            pygame.display.update()
        elif action == Action.TURN_RIGHT:
            self.direct = self.agent.turn_right()
            self.update_screen()
            pygame.display.update()
        elif action == Action.TURN_UP:
            self.direct = self.agent.turn_up()
            self.update_screen()
            pygame.display.update()
        elif action == Action.TURN_DOWN:
            self.direct = self.agent.turn_down()
            self.update_screen()
            pygame.display.update()
        elif action == Action.MOVE_FORWARD:
            self.agent.move_forward(self.direct)
            i, j = self.agent.get_pos()
            self.map.explore_cell_i_j(i, j)
            self.update_screen()
            pygame.display.update()
        elif action == Action.GRAB_GOLD:
            i, j = self.agent.get_pos()
            self.map.detect_gold(i, j)
            self.agent.grab_gold()
            self.update_screen()
            self.gold.grab_gold(self.screen, self.font)
            pygame.display.update()
            pygame.time.delay(500)
        elif action == Action.GRAB_HEALTH:
            i, j = self.agent.get_pos()
            self.agent.grab_health()
            self.update_screen()
            self.health.grab_health(self.screen, self.font)
            self.health.hp_grabbed(i , j)
            pygame.display.update()
            pygame.time.delay(500)
        elif action == Action.GET_POISONED:
            i, j = self.agent.get_pos()
            self.map.detect_poison(i, j)
            self.agent.get_poisoned()
            self.update_screen()
            self.poison.get_poisoned(self.screen, self.font)
            pygame.display.update()
            pygame.time.delay(500)
        elif action == Action.SHOOT:
            self.update_screen()
            self.agent.shoot()
            self.all_sprites.draw(self.screen)
            i, j = self.agent.get_pos()
            self.arrow.shoot(self.direct, self.screen, i, j)

            pygame.display.update()
            pygame.time.delay(500)
        elif action == Action.KILL_WUMPUS:
            self.update_screen()
            i, j = self.agent.get_pos()
            if self.direct == 0:
                i -= 1
            elif self.direct == 1:
                i += 1
            elif self.direct == 2:
                j -= 1
            elif self.direct == 3:
                j += 1
            self.wumpus.wumpus_killed(i, j)
            self.wumpus.wumpus_notification()
            i, j = self.agent.get_pos()
            if not self.wumpus.stench_i_j(i, j):
                self.wumpus.wumpus_scream(self.screen, self.font)
            pygame.display.update()
            pygame.time.delay(500)
            pass
        elif action == Action.KILL_NO_WUMPUS:
            pass
        elif action == Action.EATEN_BY_WUMPUS:
            self.agent.eliminated()
            self.all_sprites.update()
            self.draw_noti()
            self.all_sprites.draw(self.screen)
            pygame.display.update()
            self.game_state = GAMEOVER
        elif action == Action.RUN_OUT_OF_HEALTH:
            self.agent.eliminated()
            self.all_sprites.update()
            self.draw_noti()
            self.all_sprites.draw(self.screen)
            pygame.display.update()
            self.game_state = GAMEOVER
        elif action == Action.FALL_INTO_PIT:
            self.agent.eliminated()
            self.all_sprites.update()
            self.draw_noti()
            self.all_sprites.draw(self.screen)
            pygame.display.update()
            self.game_state = GAMEOVER
        elif action == Action.CLIMB_OUT_THE_CAVE:
            self.agent.climb()
            self.all_sprites.update()
            self.draw_noti()
            self.all_sprites.draw(self.screen)
            self.draw_winning_noti()
            self.game_state = WIN
            pygame.display.update()
            pygame.time.delay(2000)
        elif action == Action.DETECT_PIT:
            i, j = self.agent.get_pos()
            if self.direct == 0:
                i -= 1
            elif self.direct == 1:
                i += 1
            elif self.direct == 2:
                j -= 1
            elif self.direct == 3:
                j += 1
            self.map.detect_pit(i, j)
            self.update_screen()
            pygame.time.delay(500)
        elif action == Action.DETECT_POISON:
            i, j = self.agent.get_pos()
            if self.direct == 0:
                i -= 1
            elif self.direct == 1:
                i += 1
            elif self.direct == 2:
                j -= 1
            elif self.direct == 3:
                j += 1
            self.map.detect_poison(i, j)
            self.update_screen()
            pygame.time.delay(500)
        elif action == Action.DETECT_WUMPUS:
            pass
        elif action == Action.PERCEIVE_BREEZE:
            pass
        elif action == Action.PERCEIVE_STENCH:
            pass
        elif action == Action.PERCEIVE_GLOW:
            pass
        elif action == Action.PERCEIVE_WHIFF:
            pass
        elif action == Action.DETECT_NO_PIT:
            pass
        elif action == Action.DETECT_NO_WUMPUS:
            pass
        elif action == Action.DETECT_NO_POISON:
            pass
        elif action == Action.INFER_PIT:
            pass
        elif action == Action.INFER_NOT_PIT:
            pass
        elif action == Action.INFER_POISON:
            pass
        elif action == Action.INFER_NOT_POISON:
            pass
        elif action == Action.INFER_WUMPUS:
            pass
        elif action == Action.INFER_NOT_WUMPUS:
            pass
        elif action == Action.DETECT_SAFE:
            pass
        elif action == Action.INFER_SAFE:
            pass
        else:
            raise TypeError("Error: " + self.display_action.__name__)


    def game(self):
        while True:
            if self.game_state == MAP:
                self.home_menu()
            elif self.game_state == RUNNING:
                self.game_state = TRYBEST
                self.initialize_game_elements()
                for action in self.action_list:
                    pygame.time.delay(DELAY)
                    self.display_action(action)

                    if action == Action.CLIMB_OUT_THE_CAVE:
                        self.game_state = WIN

                    if action in [Action.FALL_INTO_PIT, Action.EATEN_BY_WUMPUS, Action.RUN_OUT_OF_HEALTH]:
                        self.game_state = GAMEOVER
                        break
                    self.check_quit_event()
            elif self.game_state in [WIN, TRYBEST]:
                self.result_noti()
                self.quit_game()
            else:
                self.result_noti()
                self.quit_game()
            self.clock.tick(60)
        

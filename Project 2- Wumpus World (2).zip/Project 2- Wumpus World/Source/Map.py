from Setting import *

class Map:
    def __init__(self, init_agent_pos):
        self.space = 9
        self.size = 10
        self.cell_size = 60
        self.unvisited_cell_image = pygame.image.load(IMG_UNVISITED_CELL).convert()
        self.visited_cell_image = pygame.image.load(IMG_VISITED_CELL).convert()
        self.pit_image = pygame.image.load(IMG_PIT).convert()
        self.poison_image = pygame.image.load(IMG_POISON).convert_alpha()
        self.gold_image = pygame.image.load(IMG_GOLD).convert_alpha()

        self.pit_explored = [[False] * self.size for _ in range(self.size)]
        self.gold_explored = [[False] * self.size for _ in range(self.size)]
        self.poison_explored = [[False] * self.size for _ in range(self.size)]
        self.cell_explored = [[False] * self.size for _ in range(self.size)]
        self.cell_explored[init_agent_pos[0] - 1][init_agent_pos[1] - 1] = True

    def draw(self, screen):
        x = self.space
        y = self.space

        for i in range(0, self.size):
            for j in range(0, self.size):
                if(self.cell_explored[i][j]): #visited cell
                    if(self.poison_explored[i][j]):
                        screen.blit(self.poison_image, (x, y))
                        x += self.space + self.cell_size
                    elif(self.gold_explored[i][j]):
                        screen.blit(self.gold_image, (x, y))
                        x += self.space + self.cell_size
                    else:
                        screen.blit(self.visited_cell_image, (x, y))
                        x += self.space + self.cell_size
                
                elif not self.cell_explored[i][j]: #unvisited cell
                    if self.pit_explored[i][j]:
                        screen.blit(self.pit_image, (x, y))
                        x += self.space + self.cell_size
                    elif(self.poison_explored[i][j]):
                        screen.blit(self.poison_image, (x, y))
                        x += self.space + self.cell_size
                    else:
                        screen.blit(self.unvisited_cell_image, (x, y))
                        x += self.space + self.cell_size
            y += self.space + self.cell_size
            x = self.space

    def explore_cell_i_j(self, i, j):
        self.cell_explored[i][j] = True

    def discovered(self):
        return self.cell_explored

    def detect_pit(self, i, j):
        self.pit_explored[i][j] = True

    def detect_gold(self, i, j):
        self.gold_explored[i][j] = True

    def detect_poison(self, i, j):
        self.poison_explored[i][j] = True
import pygame

# Speed
DELAY = 1  

# Screen dimensions
SCREEN_WIDTH = 1000
SCREEN_HEIGHT = 900

# Grid and cell settings
GRID_SIZE = 10
CELL_SIZE = 69
OFFSET = 10

# Window caption
CAPTION = 'WUMPUS WORLD'

# Colors
RED = (255, 0, 0)
BLACK = (0, 0, 0)
WHITE = (255, 255, 255)
BLUE = (0, 0, 255)
GREEN = (0, 255, 0)
PURPLE = (106, 90, 205)
YELLOW = (255, 255, 0)
ORANGE = (255, 165, 0)
GREY = (200, 200, 200)
LIGHT_GREY = (170, 170, 170)
DARK_GREY = (75, 75, 75)
PINK = (255, 182, 193)

# Images
# Cell images
IMG_UNVISITED_CELL = '../Asset/Images/unvisited_cell.png'
IMG_VISITED_CELL = '../Asset/Images/visited_cell.png'

# Object images
IMG_PIT = '../Asset/Images/pit.png'
IMG_GOLD = '../Asset/Images/gold.png'
IMG_WIN = '../Asset/Images/win.jpg'
IMG_LOSE = '../Asset/Images/lost.jpg'
IMG_POISON = '../Asset/Images/poison.png'
IMG_DEAD_WUMPUS = '../Asset/Images/wumpus.jpg'

# Agent images
IMG_AGENT_RIGHT = '../Asset/Images/agent_right.png'
IMG_AGENT_LEFT = '../Asset/Images/agent_left.png'
IMG_AGENT_UP = '../Asset/Images/agent_up.png'
IMG_AGENT_DOWN = '../Asset/Images/agent_down.png'

# Arrow images
IMG_ARROW_RIGHT = '../Asset/Images/arrow_right.png'
IMG_ARROW_LEFT = '../Asset/Images/arrow_left.png'
IMG_ARROW_UP = '../Asset/Images/arrow_up.png'
IMG_ARROW_DOWN = '../Asset/Images/arrow_down.png'

# Background image
BG_IMAGE = '../Asset/Images/background.jpg'

# Maps
MAP_LIST = [
    '../Asset/Input/map_1.txt',
    '../Asset/Input/map_2.txt',
    '../Asset/Input/map_3.txt',
    '../Asset/Input/map_4.txt',
    '../Asset/Input/map_5.txt'
]
MAP_NUM = len(MAP_LIST)

# Output files
OUTPUT_LIST = [
    '../Asset/Output/output_1.txt',
    '../Asset/Output/output_2.txt',
    '../Asset/Output/output_3.txt',
    '../Asset/Output/output_4.txt',
    '../Asset/Output/output_5.txt'
]

# Button colors
BUTTON_BORDER_COLOR = (50, 50, 50)
BUTTON_SHADOW_COLOR = (150, 150, 150)

# Button positions
MAP_1_BUTTON = pygame.Rect(300, 200, 400, 80)
MAP_2_BUTTON = pygame.Rect(300, 310, 400, 80)
MAP_3_BUTTON = pygame.Rect(300, 420, 400, 80)
MAP_4_BUTTON = pygame.Rect(300, 530, 400, 80)
MAP_5_BUTTON = pygame.Rect(300, 640, 400, 80)
EXIT_BUTTON = pygame.Rect(300, 750, 400, 80)

# Fonts
FONT = '../Asset/Fonts/Font.ttf'
FONT_2 = '../Asset/Fonts/Font2.ttf'

# Game states
RUNNING = 'running'
GAMEOVER = 'gameover'
WIN = 'win'
TRYBEST = 'trybest'
MAP = 'map'

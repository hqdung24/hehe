from Action import*
import copy
import Cell
import KnowledgeBase as KB
import pandas as pd
class Solution:
    def __init__(self, map_filename, output_filename):
        self.output_filename = output_filename

        self.map_size = None
        self.cell_matrix = None
        self.init_cell_matrix = None

        self.cave_cell = Cell.Cell((-1, -1), 10, Cell.Object.EMPTY.value)
        self.agent_cell = None
        self.init_agent_cell = None
        self.KB = KB.KnowledgeBase()
        self.path = []
        self.action_list = []
        self.score = 0
        self.hp = 100
        self.face = 'Right'
        self.read_map(map_filename)


    def read_map(self, map_filename):
        file = open(map_filename, 'r')
        self.map_size = int(file.readline())
        raw_map = [line.split('.') for line in file.read().splitlines()] #Object with no sign

        Cell.Cell((-1, -1), 10, Cell.Object.EMPTY.value).generate_sign(raw_map)
        df_map = pd.DataFrame(raw_map)
        print(df_map)
        self.cell_matrix = [[None for _ in range(self.map_size)] for _ in range(self.map_size)]
        for ir in range(self.map_size):
            for ic in range(self.map_size):
                self.cell_matrix[ir][ic] = Cell.Cell((ir, ic), self.map_size, raw_map[ir][ic])#DOC TOAN BO MAP
                if Cell.Object.AGENT.value in raw_map[ir][ic]:
                    self.agent_cell = self.cell_matrix[ir][ic]
                    self.agent_cell.update_parent(self.cave_cell)
                    self.init_agent_cell = copy.deepcopy(self.agent_cell)

        file.close()
        self.init_cell_matrix = copy.deepcopy(self.cell_matrix)


        result, pos = self.is_valid_map()
        if not result:
            if pos is None:
                raise TypeError('Input Error: The map is invalid! There is no Agent!')
            raise TypeError('Input Error: The map is invalid! Please check at row ' + str(pos[0]) + ' and column ' + str(pos[1]) + '.')


    def is_valid_map(self):
        for cell_row in self.cell_matrix:
            for cell in cell_row:
                adj_cell_list = cell.get_adj_cell_list(self.cell_matrix)
                if cell.exist_pit():
                    for adj_cell in adj_cell_list:
                        if not adj_cell.exist_breeze():
                            print('PIT FALSE')
                            return False, cell.matrix_pos
                if cell.exist_wumpus():
                    for adj_cell in adj_cell_list:
                        if not adj_cell.exist_stench():
                            print('WUMPUS FALSE')
                            return False, cell.matrix_pos
        if self.agent_cell is None:
            return False, None
        return True, None


    def write_file(self, text: str):
        out_file = open(self.output_filename, 'a')
        out_file.write(text + '\n')
        out_file.close()


    def add_action(self, action): #THEM VAO ACTION LIST, CAP NHAT HP VA SCORE
        self.action_list.append(action)
        self.write_file(action.name)

        if action == Action.TURN_LEFT:
            self.face = 'Left'
            pass
        elif action == Action.TURN_RIGHT:
            self.face = 'Right'
            pass
        elif action == Action.TURN_UP:
            self.face = 'Up'
            pass
        elif action == Action.TURN_DOWN:
            self.face = 'Down'
            pass
        elif action == Action.MOVE_FORWARD:
            self.score -= 10
            self.write_file('Score: ' + str(self.score))
        elif action == Action.GRAB_GOLD:
            self.score += 5000
            self.write_file('Score: ' + str(self.score))
        elif action == Action.GRAB_HEALTH:
            self.hp += 25
            self.write_file('HP: ' + str(self.hp))
        elif action == Action.GET_POISONED:
            self.hp -= 25
            self.write_file('HP: ' + str(self.hp) + str(self.agent_cell.exist_poison()))
        elif action == Action.PERCEIVE_BREEZE:
            pass
        elif action == Action.PERCEIVE_STENCH:
            pass
        elif action == Action.PERCEIVE_WHIFF:
            pass
        elif action == Action.PERCEIVE_GLOW:
            pass
        elif action == Action.SHOOT:
            self.score -= 100
            self.write_file('Score: ' + str(self.score))
        elif action == Action.KILL_WUMPUS:
            pass
        elif action == Action.KILL_NO_WUMPUS:
            pass
        elif action == Action.EATEN_BY_WUMPUS:
            self.score -= 10000
            self.write_file('Score: ' + str(self.score))
        elif action == Action.RUN_OUT_OF_HEALTH:
            self.score -= 10000
            self.write_file('Score: ' + str(self.score))
        elif action == Action.FALL_INTO_PIT:
            self.score -= 10000
            self.write_file('Score: ' + str(self.score))
        elif action == Action.CLIMB_OUT_THE_CAVE:
            self.score += 10
            self.write_file('Score: ' + str(self.score))
        elif action == Action.DETECT_PIT:
            pass
        elif action == Action.DETECT_POISON:
            pass
        elif action == Action.INFER_POISON:
            pass
        elif action == Action.DETECT_WUMPUS:
            pass
        elif action == Action.DETECT_NO_PIT:
            pass
        elif action == Action.DETECT_NO_POISON:
            pass
        elif action == Action.DETECT_NO_WUMPUS:
            pass
        elif action == Action.INFER_PIT:
            pass
        elif action == Action.INFER_NOT_PIT:
            pass
        elif action == Action.INFER_NOT_POISON:
            pass
        elif action == Action.INFER_WUMPUS:
            pass
        elif action == Action.INFER_NOT_WUMPUS:
            pass
        elif action == Action.DETECT_SAFE:
            pass
        elif action == Action.INFER_SAFE:
            pass
        else:
            raise TypeError("Error: " + self.add_action.__name__)

    def agent_turn(self, next_cell):
        if next_cell.map_pos[0] == self.agent_cell.map_pos[0]:
            if next_cell.map_pos[1] - self.agent_cell.map_pos[1] == 1: #DI LEN TREN
                if (self.face == 'Down'): #facing down
                    self.add_action(Action.TURN_RIGHT)
                    self.add_action(Action.TURN_UP)
                elif (self.face == 'Left' or self.face == 'Right'): ##facing left
                    self.add_action(Action.TURN_UP)
            else:#DI XUONG DUOI
                if (self.face == 'Up'): #facing down
                    self.add_action(Action.TURN_RIGHT)
                    self.add_action(Action.TURN_DOWN)
                elif (self.face == 'Left' or self.face == 'Right'): ##facing left
                    self.add_action(Action.TURN_DOWN)
        elif next_cell.map_pos[1] == self.agent_cell.map_pos[1]: #QUA PHAI
            if next_cell.map_pos[0] - self.agent_cell.map_pos[0] == 1:
                if (self.face == 'Left'): #facing left 
                    self.add_action(Action.TURN_RIGHT)
                    self.add_action(Action.TURN_RIGHT)
                elif (self.face == 'Up' or self.face == 'Down'):
                    self.add_action(Action.TURN_RIGHT)
            else:
                if (self.face == 'Right'): #facing left 
                    self.add_action(Action.TURN_LEFT)
                    self.add_action(Action.TURN_LEFT) #QUA TRAI
                elif (self.face == 'Up' or self.face == 'Down'):
                    self.add_action(Action.TURN_LEFT)

        else:
            raise TypeError('Error: ' + self.agent_turn.__name__) 

    def move_to(self, next_cell):
        self.agent_turn(next_cell)
        self.add_action(Action.MOVE_FORWARD)
        self.agent_cell = next_cell

    def add_KB_logic(self, cell):
        neighbor_list = cell.get_adj_cell_list(self.cell_matrix)

        #pit
        pit = '-'
        if cell.exist_pit():
            self.KB.add_clause([cell.get_literal(Cell.Object.PIT)])
            pit = '+'
        else:
            self.KB.add_clause([cell.get_literal(Cell.Object.PIT, '-')])
        
        #wumpus
        wumpus = '-'
        if cell.exist_wumpus():
            self.KB.add_clause([cell.get_literal(Cell.Object.WUMPUS)])
            wumpus = '+'
        else:
            self.KB.add_clause([cell.get_literal(Cell.Object.WUMPUS, '-')])

        if wumpus == pit == '+':
            print("Wumpus and pit cannot be in the same cell")
            return False
        
        #poison
        if cell.exist_poison():
            self.KB.add_clause([cell.get_literal(Cell.Object.POISONOUS_GAS)])
        else:
            self.KB.add_clause([cell.get_literal(Cell.Object.POISONOUS_GAS, '-')])

        #healing:
        if cell.exist_health():
            self.KB.add_clause([cell.get_literal(Cell.Object.HEALING_POTIONS)])
        else:
            self.KB.add_clause([cell.get_literal(Cell.Object.HEALING_POTIONS, '-')])

        #B <=> Pa V Pb V Pc V Pd
        sign = '-'
        if cell.exist_breeze():
            sign = '+'
        self.KB.add_clause([cell.get_literal(Cell.Object.BREEZE, sign)])

        if cell.exist_breeze():
            clause = [cell.get_literal(Cell.Object.BREEZE, '-')]
            for neighbor in neighbor_list: #Add Bij => Pa V Pb V Pc V Pd (a, b, c, d neighbor of [i,j])
                clause.append(neighbor.get_literal(Cell.Object.PIT))
            self.KB.add_clause(clause)

            for neighbor in neighbor_list: #(Pa V Pb V Pc V Pd) => Bij
                clause = [cell.get_literal(Cell.Object.BREEZE), neighbor.get_literal(Cell.Object.PIT, '-')]
                self.KB.add_clause(clause)

        else: #No breeze
            for neighbor in neighbor_list:
                self.KB.add_clause([neighbor.get_literal(Cell.Object.PIT, '-')])
        
        #S <=> Wa V Wb V Wc V Wd 
        sign = '-'
        if cell.exist_stench():
            sign = '+'
        self.KB.add_clause([cell.get_literal(Cell.Object.STENCH, sign)])

        if cell.exist_stench():
            clause = [cell.get_literal(Cell.Object.STENCH, '-')]
            for neighbor in neighbor_list: #Add S => Wa V Wb V Wc V Wd 
                clause.append(neighbor.get_literal(Cell.Object.WUMPUS))
            self.KB.add_clause(clause)

            for neighbor in neighbor_list:
                clause = [cell.get_literal(Cell.Object.STENCH), neighbor.get_literal(Cell.Object.WUMPUS, '-')]
                self.KB.add_clause(clause)

        else: #No Stench
            for neighbor in neighbor_list:
                self.KB.add_clause([neighbor.get_literal(Cell.Object.WUMPUS, '-')])

        #W_H <=> P_Ga v P_Gb v P_Gc v P_Gd
        sign = '-'
        if cell.exist_whiff():
            sign = '+'
        self.KB.add_clause([cell.get_literal(Cell.Object.WHIFF, sign)])

        if cell.exist_whiff(): 
            clause = [cell.get_literal(Cell.Object.WHIFF, '-')]
            for neighbor in neighbor_list: #W_H => P_Ga V P_Gb V P_Gc V P_Gd 
                clause.append(neighbor.get_literal(Cell.Object.POISONOUS_GAS))
            self.KB.add_clause(clause)

            for neighbor in neighbor_list:
                clause = [cell.get_literal(Cell.Object.WHIFF), neighbor.get_literal(Cell.Object.POISONOUS_GAS, '-')]
                self.KB.add_clause(clause)

        else: #No whiff
            for neighbor in neighbor_list:
                self.KB.add_clause([neighbor.get_literal(Cell.Object.POISONOUS_GAS, '-')])
        self.write_file(str(self.KB.KB))

    def precheck(self):
        if self.agent_cell.exist_pit():
            self.add_action(Action.FALL_INTO_PIT)
            return False

        if self.agent_cell.exist_wumpus():
            self.add_action(Action.EATEN_BY_WUMPUS)
            return False
        if self.hp == 0:
            self.add_action(Action.RUN_OUT_OF_HEALTH)
            return False

        if self.agent_cell.exist_gold():
            self.add_action(Action.GRAB_GOLD)
            self.agent_cell.grab_gold()

        if self.agent_cell.exist_health():
            self.add_action(Action.GRAB_HEALTH)
            self.agent_cell.grab_health()

        if self.agent_cell.exist_poison():
            self.add_action(Action.GET_POISONED)
            self.agent_cell.grab_poison()

        if self.agent_cell.exist_breeze():
            self.add_action(Action.PERCEIVE_BREEZE)

        if self.agent_cell.exist_whiff():
            self.add_action(Action.PERCEIVE_WHIFF)

        if self.agent_cell.exist_glow():
            self.add_action(Action.PERCEIVE_GLOW)

        if self.agent_cell.exist_stench():
            self.add_action(Action.PERCEIVE_STENCH)

        if not self.agent_cell.is_explored():
            self.agent_cell.explore()
            self.add_KB_logic(self.agent_cell)
        return True

    def backtracking(self):
        if not self.precheck():
            return False
        adjacent_cells = self.agent_cell.get_adj_cell_list(self.cell_matrix)

        temp_adjacent_cells = []
        if self.agent_cell.parent in adjacent_cells:
            adjacent_cells.remove(self.agent_cell.parent)

        previous_agent_cell = self.agent_cell

        # If the current cell is safe, move to all valid adjacent cells.
        # If not, infer based on KB to make decisions.
        if not self.agent_cell.is_safe():
            # Remove explored cells with Pit from adjacent cells list.
            temp_adjacent_cells = []
            for cell in adjacent_cells:
                if cell.is_explored() and cell.exist_pit() or (cell.is_explored() and cell.exist_poison()):
                    temp_adjacent_cells.append(cell)
            for cell in temp_adjacent_cells:
                adjacent_cells.remove(cell)

            temp_adjacent_cells = []

            # If the current cell has Stench, infer whether adjacent cells have Wumpus.
            if self.agent_cell.exist_stench():
                for cell in adjacent_cells:
                    print("Infer: ", end='')
                    print(cell.map_pos)
                    self.write_file('Infer: ' + str(cell.map_pos))
                    self.agent_turn(cell)

                    # Infer Wumpus.
                    self.add_action(Action.INFER_WUMPUS)
                    not_alpha = [[cell.get_literal(Cell.Object.WUMPUS, '-')]]
                    has_wumpus = self.KB.infer(not_alpha)

                    # If Wumpus is inferred.
                    if has_wumpus:
                        # Detect Wumpus.
                        self.add_action(Action.DETECT_WUMPUS)

                        # Shoot the Wumpus.
                        self.add_action(Action.SHOOT)
                        self.add_action(Action.KILL_WUMPUS)
                        cell.kill_wumpus(self.cell_matrix, self.KB)
                        self.write_file('KB: ' + str(self.KB.KB))

                    # If Wumpus is not inferred.
                    else:
                        # Infer not Wumpus.
                        self.add_action(Action.INFER_NOT_WUMPUS)
                        not_alpha = [[cell.get_literal(Cell.Object.WUMPUS, '+')]]
                        has_no_wumpus = self.KB.infer(not_alpha)

                        # If not Wumpus is inferred.
                        if has_no_wumpus:
                            # Detect no Wumpus.
                            self.add_action(Action.DETECT_NO_WUMPUS)

                        # If not Wumpus is not inferred.
                        else:
                            # Add to the list of cells to check further.
                            if cell not in temp_adjacent_cells:
                                temp_adjacent_cells.append(cell)

            # If Stench is still present after inference, try shooting in all directions until Stench disappears.
            if self.agent_cell.exist_stench():
                cells_to_check = self.agent_cell.get_adj_cell_list(self.cell_matrix)
                if self.agent_cell.parent in cells_to_check:
                    cells_to_check.remove(self.agent_cell.parent)

                explored_cells = []
                for cell in cells_to_check:
                    if cell.is_explored():
                        explored_cells.append(cell)
                for cell in explored_cells:
                    cells_to_check.remove(cell)

                for cell in cells_to_check:
                    print("Try: ", end='')
                    print(cell.map_pos)
                    self.write_file('Try: ' + str(cell.map_pos))
                    self.agent_turn(cell)

                    self.add_action(Action.SHOOT)
                    if cell.exist_wumpus():
                        self.add_action(Action.KILL_WUMPUS)
                        cell.kill_wumpus(self.cell_matrix, self.KB)
                        self.write_file('KB: ' + str(self.KB.KB))

                    if not self.agent_cell.exist_stench():
                        self.agent_cell.update_child_list([cell])
                        break

        # Infer cells with Whiff when HP is below 50%.
        if self.agent_cell.exist_whiff():
            for cell in adjacent_cells:
                self.write_file('Infer: ' + str(cell.map_pos))
                self.agent_turn(cell)
                self.add_action(Action.INFER_POISON)
                not_alpha = [[cell.get_literal(Cell.Object.PIT, '-')]]
                has_pit = self.KB.infer(not_alpha)

                if has_pit:
                    self.add_action(Action.DETECT_POISON)
                    cell.explore()
                    self.add_KB_logic(cell)
                    cell.update_parent(cell)
                    temp_adjacent_cells.append(cell)

                else:
                    self.add_action(Action.INFER_NOT_POISON)
                    not_alpha = [[cell.get_literal(Cell.Object.POISONOUS_GAS, '+')]]
                    has_no_poison = self.KB.infer(not_alpha)
                    if has_no_poison:
                        self.add_action(Action.DETECT_NO_POISON)
                    else:
                        if self.hp <= 75:
                            temp_adjacent_cells.append(cell)
        
        if self.agent_cell.exist_breeze():
            for cell in adjacent_cells:
                self.write_file('Infer: ' + str(cell.map_pos))
                self.agent_turn(cell)

                # Infer Pit.
                self.add_action(Action.INFER_PIT)
                not_alpha = [[cell.get_literal(Cell.Object.PIT, '-')]]
                has_pit = self.KB.infer(not_alpha)

                # If Pit is inferred.
                if has_pit:
                    self.add_action(Action.DETECT_PIT)
                    cell.explore()
                    self.add_KB_logic(cell)
                    cell.update_parent(cell)
                    temp_adjacent_cells.append(cell)

                else:
                    # Infer not Pit.
                    self.add_action(Action.INFER_NOT_PIT)
                    not_alpha = [[cell.get_literal(Cell.Object.PIT, '+')]]
                    has_no_pit = self.KB.infer(not_alpha)

                    if has_no_pit:
                        self.add_action(Action.DETECT_NO_PIT)

                    else:
                        temp_adjacent_cells.append(cell)

        temp_adjacent_cells = list(set(temp_adjacent_cells))

        for cell in temp_adjacent_cells:
            adjacent_cells.remove(cell)
        self.agent_cell.update_child_list(adjacent_cells)

        for next_cell in self.agent_cell.child_list:
            if previous_agent_cell.exist_poison():
                continue
            self.move_to(next_cell)
            self.write_file('Move to: ' + str(self.agent_cell.map_pos))

            if not self.backtracking():
                return False


            if previous_agent_cell.exist_poison():
                self.add_action(Action.GET_POISONED)
                previous_agent_cell.grab_poison()
            self.move_to(previous_agent_cell)
            self.write_file('Backtrack: ' + str(previous_agent_cell.map_pos))

        return True



    def solve_wumpus(self):
        out_file = open(self.output_filename, 'w')
        out_file.close()

        self.backtracking()

        for cell_row in self.cell_matrix:
            for cell in cell_row:
                if cell.exist_gold() or cell.exist_wumpus():
                    break

        if self.agent_cell.parent == self.cave_cell:
            self.add_action(Action.CLIMB_OUT_THE_CAVE)

        return self.action_list, self.init_agent_cell, self.init_cell_matrix

from Game import *

def main():
    Game().game()

if __name__ == "__main__":
    try:
        main()
    except Exception as e:
        print(f"An error occurred: {e}")
        pygame.quit()
        input("Press Enter to exit...")
        sys.exit(1)